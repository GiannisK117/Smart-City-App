import { useRouter } from "expo-router";
import { useEffect, useState } from "react";

import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

// Firebase
import {
  collection,
  onSnapshot,
  orderBy,
  query,
} from "firebase/firestore";

import { db } from "./firebaseConfig";

export default function ReportsScreen() {

  const router = useRouter();

  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {

    const q = query(
      collection(db, "reports"),
      orderBy("timestamp", "desc")
    );

    const unsubscribe = onSnapshot(q, (querySnapshot) => {

      const reportsArray: any[] = [];

      querySnapshot.forEach((doc) => {

        reportsArray.push({
          id: doc.id,
          ...doc.data(),
        });

      });

      setReports(reportsArray);
      setLoading(false);

    });

    return () => unsubscribe();

  }, []);

  const renderItem = ({ item }: any) => (

    <View style={styles.card}>

      {/* CATEGORY */}
      <Text style={styles.cardTitle}>
        {item.category || "Γενικό Πρόβλημα"}
      </Text>

      {/* DESCRIPTION */}
      <Text style={styles.cardText}>
        {item.description || "Χωρίς περιγραφή"}
      </Text>

      {/* IMAGE */}
      {item.image && (
        <Image
          source={{ uri: item.image }}
          style={styles.reportImage}
        />
      )}

      {/* STATUS */}
      <Text style={styles.status}>
        Κατάσταση: {item.status}
      </Text>

      {/* DATE */}
      <Text style={styles.cardDate}>
        {item.timestamp?.toDate
          ? item.timestamp
              .toDate()
              .toLocaleString()
          : "Εκκρεμεί ημερομηνία..."}
      </Text>

    </View>

  );

  return (

    <View style={styles.container}>

      <Text style={styles.title}>
        Αναφορές Πολιτών
      </Text>

      {loading ? (

        <ActivityIndicator
          size="large"
          color="#2f8bd6"
          style={{ marginTop: 50 }}
        />

      ) : reports.length === 0 ? (

        <Text style={styles.noReports}>
          Δεν υπάρχουν αναφορές στο Cloud.
        </Text>

      ) : (

        <FlatList
          data={reports}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={{
            paddingBottom: 20,
          }}
        />

      )}

      {/* HOME BUTTON */}
      <View style={styles.buttonContainer}>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push("/")}
        >
          <Text style={styles.buttonText}>
            ΕΠΙΣΤΡΟΦΗ ΣΤΗΝ ΑΡΧΙΚΗ
          </Text>
        </TouchableOpacity>

      </View>

    </View>

  );

}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#f4f6f8",
    paddingTop: 20,
  },

  title: {
    fontSize: 26,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 10,
    color: "#111",
  },

  noReports: {
    textAlign: "center",
    color: "#888",
    marginTop: 40,
    fontSize: 16,
  },

  card: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 14,
    marginHorizontal: 20,
    marginTop: 12,
    elevation: 3,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 5,
    color: "#2f8bd6",
  },

  cardText: {
    fontSize: 14,
    color: "#444",
  },

  reportImage: {
    width: "100%",
    height: 220,
    borderRadius: 12,
    marginTop: 12,
    marginBottom: 10,
  },

  status: {
    marginTop: 5,
    fontSize: 13,
    fontWeight: "600",
    color: "#e67e22",
  },

  cardDate: {
    marginTop: 8,
    fontSize: 12,
    color: "#777",
  },

  buttonContainer: {
    paddingHorizontal: 20,
    paddingBottom: 25,
    paddingTop: 10,
  },

  button: {
    backgroundColor: "#2f8bd6",
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
  },

  buttonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 15,
  },

});