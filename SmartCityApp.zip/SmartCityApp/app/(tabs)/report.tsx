import { Picker } from "@react-native-picker/picker";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import React, { useState } from "react";

import {
  ActivityIndicator,
  Alert,
  Image,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

// Firebase + Location
import * as Location from "expo-location";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "./firebaseConfig";

export default function ReportScreen() {
  const router = useRouter();

  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [loading, setLoading] = useState(false);

  // Image state
  const [image, setImage] = useState<string | null>(null);

  // CAMERA FUNCTION
  const takePhoto = async () => {
    const permission =
      await ImagePicker.requestCameraPermissionsAsync();

    if (!permission.granted) {
      Alert.alert(
        "Permission Denied",
        "Camera permission is required."
      );
      return;
    }

    const result =
      await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        quality: 0.7,
      });

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  // SAVE REPORT
  const saveReport = async () => {
    if (!category || !description) {
      Alert.alert(
        "Προσοχή",
        "Παρακαλώ επιλέξτε κατηγορία και περιγράψτε το πρόβλημα."
      );
      return;
    }

    setLoading(true);

    try {
      // GPS LOCATION
      let { status } =
        await Location.requestForegroundPermissionsAsync();

      let locationData = null;

      if (status === "granted") {
        const location =
          await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.High,
          });

        locationData = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };
      }

      // FIREBASE SAVE
      await addDoc(collection(db, "reports"), {
        category: category,
        description: description,
        status: "pending",

        // CAMERA IMAGE
        image: image,

        // GPS
        location: locationData,

        timestamp: serverTimestamp(),
      });

      Alert.alert(
        "Επιτυχία",
        "Η αναφορά καταχωρήθηκε επιτυχώς!"
      );

      // RESET
      setCategory("");
      setDescription("");
      setImage(null);

      router.push("/reports");

    } catch (error) {
      console.error("Firebase Error:", error);

      Alert.alert(
        "Σφάλμα",
        "Αποτυχία σύνδεσης με Firebase."
      );

    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>
        Νέα Αναφορά Βλάβης
      </Text>

      <View style={styles.card}>

        {/* CATEGORY */}
        <Text style={styles.label}>Κατηγορία</Text>

        <View style={styles.pickerContainer}>
          <Picker
            selectedValue={category}
            onValueChange={(itemValue) =>
              setCategory(itemValue)
            }
          >
            <Picker.Item
              label="Επιλέξτε είδος βλάβης..."
              value=""
            />

            <Picker.Item
              label="Οδόστρωμα / Λακκούβες"
              value="Road"
            />

            <Picker.Item
              label="Ηλεκτροφωτισμός"
              value="Light"
            />

            <Picker.Item
              label="Καθαριότητα / Κάδοι"
              value="Garbage"
            />

            <Picker.Item
              label="Ύδρευση / Αποχέτευση"
              value="Water"
            />

            <Picker.Item
              label="Πράσινο / Δέντρα"
              value="Green"
            />
          </Picker>
        </View>

        {/* DESCRIPTION */}
        <Text style={styles.label}>
          Περιγραφή Προβλήματος
        </Text>

        <TextInput
          style={styles.textArea}
          placeholder="Περιγράψτε το πρόβλημα..."
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
        />

        {/* CAMERA BUTTON */}
        <TouchableOpacity
          style={styles.cameraButton}
          onPress={takePhoto}
        >
          <Text style={styles.buttonText}>
            📷 TAKE PHOTO
          </Text>
        </TouchableOpacity>

        {/* IMAGE PREVIEW */}
        {image && (
          <Image
            source={{ uri: image }}
            style={styles.preview}
          />
        )}

        {/* SUBMIT */}
        <TouchableOpacity
          style={[
            styles.button,
            loading && {
              backgroundColor: "#8ebcea",
            },
          ]}
          onPress={saveReport}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="white" />
          ) : (
            <Text style={styles.buttonText}>
              ΑΠΟΣΤΟΛΗ ΑΝΑΦΟΡΑΣ
            </Text>
          )}
        </TouchableOpacity>

        {/* CANCEL */}
        <TouchableOpacity
          style={styles.secondaryButton}
          onPress={() => router.push("/")}
        >
          <Text style={styles.secondaryText}>
            ΑΚΥΡΩΣΗ
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.footerNote}>
        * Η τοποθεσία καταγράφεται αυτόματα
        για ταχύτερη εξυπηρέτηση.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flexGrow: 1,
    backgroundColor: "#f0f2f5",
    padding: 20,
    paddingBottom: 40,
  },

  title: {
    fontSize: 26,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    marginTop: 20,
    color: "#1a1a1a",
  },

  card: {
    backgroundColor: "white",
    borderRadius: 15,
    padding: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },

  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: "bold",
    color: "#444",
  },

  pickerContainer: {
    backgroundColor: "#fafafa",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#e0e0e0",
    marginBottom: 20,
    overflow: "hidden",
  },

  textArea: {
    backgroundColor: "#fafafa",
    padding: 15,
    borderRadius: 10,
    height: 120,
    textAlignVertical: "top",
    marginBottom: 25,
    borderWidth: 1,
    borderColor: "#e0e0e0",
    fontSize: 16,
  },

  cameraButton: {
    backgroundColor: "#444",
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 15,
  },

  preview: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    marginBottom: 20,
  },

  button: {
    backgroundColor: "#007AFF",
    padding: 18,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 12,
  },

  buttonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },

  secondaryButton: {
    padding: 15,
    alignItems: "center",
  },

  secondaryText: {
    color: "#666",
    fontWeight: "600",
  },

  footerNote: {
    textAlign: "center",
    color: "#888",
    fontSize: 12,
    marginTop: 20,
    lineHeight: 18,
  },
});