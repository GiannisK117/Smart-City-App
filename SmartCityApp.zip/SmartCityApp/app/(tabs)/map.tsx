import * as Location from "expo-location";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";

// Εισαγωγή Firebase
import { collection, onSnapshot, query } from "firebase/firestore";
import { db } from "./firebaseConfig";

let MapView: any;
let Marker: any;

if (Platform.OS !== "web") {
  const maps = require("react-native-maps");
  MapView = maps.default;
  Marker = maps.Marker;
}

export default function MapScreen() {
  const [location, setLocation] = useState<any>(null);
  const [markers, setMarkers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 1. Πάρε την τρέχουσα τοποθεσία του χρήστη για να κεντράρει ο χάρτης
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status === "granted") {
        const loc = await Location.getCurrentPositionAsync({});
        setLocation(loc);
      }
    })();

    // 2. REAL-TIME Σύνδεση με Firebase για να τραβήξουμε όλες τις αναφορές
    const q = query(collection(db, "reports"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const reportsData: any[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        // Ελέγχουμε αν η αναφορά έχει συντεταγμένες
        if (
          data.location &&
          data.location.latitude &&
          data.location.longitude
        ) {
          reportsData.push({
            id: doc.id,
            ...data,
          });
        }
      });
      setMarkers(reportsData);
      setLoading(false);
    });

    return () => unsubscribe(); // Διακοπή σύνδεσης όταν κλείνει η οθόνη
  }, []);

  if (Platform.OS === "web") {
    return (
      <View style={styles.center}>
        <Text>Ο χάρτης δεν υποστηρίζεται στον browser.</Text>
      </View>
    );
  }

  // Αρχικό κεντράρισμα (Αθήνα ή η τοποθεσία του χρήστη)
  const initialRegion = {
    latitude: location?.coords?.latitude ?? 37.9838,
    longitude: location?.coords?.longitude ?? 23.7275,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };

  return (
    <View style={{ flex: 1 }}>
      {loading && (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color="#007AFF" />
        </View>
      )}

      <MapView style={{ flex: 1 }} initialRegion={initialRegion}>
        {/* Πινέζες από το Firebase */}
        {markers.map((m) => (
          <Marker
            key={m.id}
            coordinate={{
              latitude: m.location.latitude,
              longitude: m.location.longitude,
            }}
            title={m.category}
            description={m.description}
            pinColor={m.status === "resolved" ? "green" : "red"} // Πράσινο αν λύθηκε, κόκκινο αν εκκρεμεί
          />
        ))}
      </MapView>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingOverlay: {
    position: "absolute",
    zIndex: 2,
    top: "50%",
    left: "50%",
    marginLeft: -20,
  },
});
