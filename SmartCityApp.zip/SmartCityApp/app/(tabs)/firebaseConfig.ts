import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

// Οι ρυθμίσεις σου από το Firebase Console
const firebaseConfig = {
  apiKey: "AIzaSyBhwCDRHtChnaNR40QzK1GuAkLph3ARWZE",
  authDomain: "mobile-app-cef6c.firebaseapp.com",
  projectId: "mobile-app-cef6c",
  storageBucket: "mobile-app-cef6c.firebasestorage.app",
  messagingSenderId: "966458193198",
  appId: "1:966458193198:web:47b2629b0407ad7d1676bf",
  measurementId: "G-WMYYQSEVR5",
};

// Αρχικοποίηση του Firebase
const app = initializeApp(firebaseConfig);

// Εξαγωγή της βάσης δεδομένων για χρήση στα άλλα αρχεία (π.χ. report.tsx)
export const db = getFirestore(app);
